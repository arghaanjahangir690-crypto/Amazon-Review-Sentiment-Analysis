
READ ME FIRST

Dataset:
dataset.csv

Dataset Type:
Amazon Product Reviews Dataset

Recommended Project:
Amazon Review Sentiment Analysis

Target:
sentiment_label created from rating

Main Feature:
review_content

Important:
Do not use rating as an input feature after creating sentiment_label.
Do not use product_id, user_id, user_name, review_id, img_link, product_link in model training.

Next Steps:
1. Create cleaned dataset
2. Create sentiment labels
3. Apply TF-IDF
4. Train ML models
5. Save results
6. Prepare documentation
7. Upload package to GitHub
